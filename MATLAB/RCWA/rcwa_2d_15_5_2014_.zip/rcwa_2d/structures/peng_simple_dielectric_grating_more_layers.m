number_of_layers=2;

l=1; % layer 1
thickness(l)=0.5;

coordinate_x_1=1.2.*[0,0.15,0.45,1];
coordinate_y_1=1.2.*[0,0.15,0.45,1];

r_index_1=[1, 1, 1;
    1, 0.1-6.71*1i, 1;
    1, 1, 1];


l=2; % layer 2
thickness(l)=0.5;

coordinate_x_2=1.2.*[0,0.15,0.45,1];
coordinate_y_2=1.2.*[0,0.15,0.45,1];

r_index_2=[1, 1, 1;
    1, 0.1-6.71*1i, 1;
    1, 1, 1];

%{
l=3; % layer 3
thickness(l)=0.5;

coordinate_x_3=1.2.*[0,1];
coordinate_y_3=1.2.*[0,1];

r_index_3=[1.5];
%}