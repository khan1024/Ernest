number_of_layers=1;

load pokus.mat

l=1;
thickness(l)=1.0;

px(:,:,l)=px_mat;
py(:,:,l)=py_mat;
n_mat(:,:,l)=mesh_n_mat;

