function f = myfun(x,d,a)
fce=abs(sin(x)).^(1/2)
f=d*fce-a;