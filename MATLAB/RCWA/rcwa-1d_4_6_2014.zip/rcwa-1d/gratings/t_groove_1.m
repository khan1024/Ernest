h_1=0.3;
h_2=0.35;
W_1=0.2;
W_2=0.05;
P=1.1;

data=[
h_1, 0, silver, P/2-W_1/2, 1, P/2+W_1/2, silver, P;
h_2, 0, silver, P/2-W_2/2, 1, P/2+W_2/2, silver, P;
];

n1=1;
n3=silver;