eps_fe3si=(5.3-6.3*1i);

data=[0.08,0,sqrt(eps_fe3si),0.6,1,1.6]; 

n1=1;
n3=1;
lambda=1;
theta0=0;
