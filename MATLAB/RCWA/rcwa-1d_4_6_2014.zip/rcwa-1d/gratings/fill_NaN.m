% add_hom_layer(layer_number,Lambda,layer_thickness,ref_index)

function matrix=fill_NaN(r,s)

matrix=zeros(r,s);
matrix(:,:)=NaN;


