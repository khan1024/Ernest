gold_thickness=0.05;
perioda=0.8;

% indexy lomu v souboru nastaveni_indexu.m
%vrstvy
data=[
gold_thickness, 0, gold, perioda;
];
%n3=water;
%n1=BK7;