n1=1.0;
n3=1.5;
lambda=1;
theta0=0;

data=[1,0,1.5,1,1,2]; 


